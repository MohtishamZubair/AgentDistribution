import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { MainModule } from './app.module';

platformBrowserDynamic().bootstrapModule(MainModule);
